require('dotenv').config();

const path = require('path');
const express = require('express');
const { auth, requiresAuth } = require('express-openid-connect');
const { getUser, updateUserMetadata } = require('./services/auth0Management');

const app = express();
const PORT = process.env.PORT || 3000;

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: false }));

// ---------------------------------------------------------------------------
// PUNTO 1: Autenticación con la librería oficial de Auth0 (express-openid-connect)
// Crea automáticamente las rutas /login, /logout y /callback
// ---------------------------------------------------------------------------
app.use(
  auth({
    authRequired: false,
    auth0Logout: true,
    secret: process.env.SECRET,
    baseURL: process.env.BASE_URL,
    clientID: process.env.AUTH0_CLIENT_ID,
    issuerBaseURL: `https://${process.env.AUTH0_DOMAIN}`,
  })
);

// Variables disponibles en todas las vistas
app.use((req, res, next) => {
  res.locals.isAuthenticated = req.oidc.isAuthenticated();
  res.locals.user = req.oidc.user || null;
  next();
});

const TIPOS_DOCUMENTO = [
  { valor: 'CC', texto: 'Cédula de ciudadanía' },
  { valor: 'TI', texto: 'Tarjeta de identidad' },
  { valor: 'CE', texto: 'Cédula de extranjería' },
  { valor: 'PA', texto: 'Pasaporte' },
];

// Página de inicio
app.get('/', (req, res) => {
  res.render('index');
});

// ---------------------------------------------------------------------------
// PUNTO 3: Formulario de datos, prellenado desde user_metadata
// ---------------------------------------------------------------------------
app.get('/perfil', requiresAuth(), async (req, res) => {
  try {
    const usuario = await getUser(req.oidc.user.sub);
    const metadata = usuario.user_metadata || {}; // vacío la primera vez

    res.render('perfil', {
      tipos: TIPOS_DOCUMENTO,
      datos: metadata,
      metadataActual: metadata,
      exito: req.query.ok === '1',
      error: null,
    });
  } catch (err) {
    console.error(err);
    res.status(500).render('perfil', {
      tipos: TIPOS_DOCUMENTO,
      datos: {},
      metadataActual: {},
      exito: false,
      error: 'No se pudieron consultar los datos en Auth0: ' + err.message,
    });
  }
});

// ---------------------------------------------------------------------------
// PUNTO 4: Guardar los datos en user_metadata usando la Management API
// ---------------------------------------------------------------------------
app.post('/perfil', requiresAuth(), async (req, res) => {
  const datos = {
    tipo_documento: (req.body.tipo_documento || '').trim(),
    numero_documento: (req.body.numero_documento || '').trim(),
    direccion: (req.body.direccion || '').trim(),
    telefono: (req.body.telefono || '').trim(),
  };

  const errores = validar(datos);
  if (errores.length) {
    return res.status(400).render('perfil', {
      tipos: TIPOS_DOCUMENTO,
      datos,
      metadataActual: {},
      exito: false,
      error: errores.join(' '),
    });
  }

  try {
    await updateUserMetadata(req.oidc.user.sub, datos);
    res.redirect('/perfil?ok=1');
  } catch (err) {
    console.error(err);
    res.status(500).render('perfil', {
      tipos: TIPOS_DOCUMENTO,
      datos,
      metadataActual: {},
      exito: false,
      error: 'No se pudo guardar en Auth0: ' + err.message,
    });
  }
});

function validar(d) {
  const errores = [];
  if (!TIPOS_DOCUMENTO.some((t) => t.valor === d.tipo_documento)) {
    errores.push('Selecciona un tipo de documento válido.');
  }
  if (!/^[A-Za-z0-9]{5,15}$/.test(d.numero_documento)) {
    errores.push('El número de documento debe tener entre 5 y 15 caracteres alfanuméricos.');
  }
  if (d.direccion.length < 5) {
    errores.push('La dirección es muy corta.');
  }
  if (!/^\+?[0-9\s-]{7,15}$/.test(d.telefono)) {
    errores.push('El teléfono no es válido.');
  }
  return errores;
}

app.listen(PORT, () => {
  console.log(`Aplicación corriendo en ${process.env.BASE_URL || 'http://localhost:' + PORT}`);
});
