// Cliente para la Auth0 Management API v2
// Docs: https://auth0.com/docs/api/management/v2

const DOMAIN = process.env.AUTH0_DOMAIN;

let tokenEnCache = null;
let expiraEn = 0;

/**
 * Obtiene un access token para la Management API usando el flujo
 * Client Credentials con la aplicación Machine to Machine.
 * El token se guarda en memoria hasta poco antes de que expire.
 */
async function getManagementToken() {
  if (tokenEnCache && Date.now() < expiraEn) return tokenEnCache;

  const resp = await fetch(`https://${DOMAIN}/oauth/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      grant_type: 'client_credentials',
      client_id: process.env.AUTH0_M2M_CLIENT_ID,
      client_secret: process.env.AUTH0_M2M_CLIENT_SECRET,
      audience: `https://${DOMAIN}/api/v2/`,
    }),
  });

  if (!resp.ok) {
    throw new Error(`Error obteniendo token (${resp.status}): ${await resp.text()}`);
  }

  const data = await resp.json();
  tokenEnCache = data.access_token;
  expiraEn = Date.now() + (data.expires_in - 60) * 1000;
  return tokenEnCache;
}

/** GET /api/v2/users/{id} — trae el usuario con su user_metadata */
async function getUser(userId) {
  const token = await getManagementToken();
  const resp = await fetch(`https://${DOMAIN}/api/v2/users/${encodeURIComponent(userId)}`, {
    headers: { Authorization: `Bearer ${token}` },
  });

  if (!resp.ok) {
    throw new Error(`Error consultando usuario (${resp.status}): ${await resp.text()}`);
  }
  return resp.json();
}

/** PATCH /api/v2/users/{id} — actualiza solo la sección user_metadata */
async function updateUserMetadata(userId, metadata) {
  const token = await getManagementToken();
  const resp = await fetch(`https://${DOMAIN}/api/v2/users/${encodeURIComponent(userId)}`, {
    method: 'PATCH',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ user_metadata: metadata }),
  });

  if (!resp.ok) {
    throw new Error(`Error actualizando usuario (${resp.status}): ${await resp.text()}`);
  }
  return resp.json();
}

module.exports = { getUser, updateUserMetadata };
